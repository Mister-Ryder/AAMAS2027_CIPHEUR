You are a cold program-authoring session. Read only this packet and its prompt; do not read existing programs, outcome files, manuscript, other banks, or any test data. Use the supplied grammar to author exactly 12 candidate slots in one batch. Do not evaluate schedules or run the oracle. Do not copy another arm. Write the exact JSON response once; invalid, missing and exact-duplicate deployment AST slots will remain failed attempts without replacements. No outcome-informed follow-up or selection is allowed. Your own technical reasoning is allowed. Preserve all candidates, including uncertain hypotheses.

Packet: `E:/01-Joycecyq/2026-AAMAS/第二篇/experiments/discovery/v05/packets/block_2_objective.json`
Response: `E:/01-Joycecyq/2026-AAMAS/第二篇/experiments/discovery/v05/responses/block_2_objective.json`
Use version matched_cold_bank_v05, block 2, arm objective. Each candidate must have exactly name,features,rule,rationale. Output JSON only in that response file.
