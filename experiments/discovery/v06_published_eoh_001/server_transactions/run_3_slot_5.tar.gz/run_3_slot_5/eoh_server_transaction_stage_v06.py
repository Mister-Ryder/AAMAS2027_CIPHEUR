"""Stage exact transaction bytes and detach one TRAIN-only frozen evaluator."""
from pathlib import Path,PurePosixPath
from hashlib import sha256
import argparse,json,os,signal,subprocess,time,zipfile
ROOT=Path(__file__).resolve().parent
PYTHON='/root/autodl-tmp/aamas2027_v03/py311/bin/python'
PREFIX='experiments/discovery/v06_published_eoh_001/'

def main():
 p=argparse.ArgumentParser();p.add_argument('--capsule',required=True);p.add_argument('--sha256',required=True);p.add_argument('--transaction',required=True);a=p.parse_args()
 name=a.transaction
 assert name.startswith('run_') and all(c.isalnum() or c=='_' for c in name)
 capsule=ROOT/a.capsule;assert sha256(capsule.read_bytes()).hexdigest()==a.sha256
 assert not (ROOT/f'{name}.staging_receipt.json').exists()
 members=[]
 with zipfile.ZipFile(capsule) as z:
  for m in z.infolist():
   assert not m.is_dir() and m.filename.startswith(PREFIX) and '..' not in PurePosixPath(m.filename).parts and '\\' not in m.filename
   dest=(ROOT/m.filename).resolve();assert dest.is_relative_to(ROOT.resolve())
   raw=z.read(m);existing=dest.exists()
   if existing:assert dest.read_bytes()==raw,'Existing transaction byte mismatch'
   else:dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw)
   members.append({'path':m.filename,'sha256':sha256(raw).hexdigest(),'preexisting_exact_bytes':existing})
 receipt={'transaction':name,'capsule_sha256':a.sha256,'members':members,'staged_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'TEST_accessed':False,'no_authors_or_model_calls':True}
 (ROOT/f'{name}.staging_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
 # Pause only this project's separately authorized input preparation groups.
 prep=Path('/root/autodl-tmp/aamas2027_v06_performance_r2_eoh_test_003')
 paused=[]
 for proc in Path('/proc').iterdir():
  if not proc.name.isdigit():continue
  try:
   args=[s.decode() for s in (proc/'cmdline').read_bytes().split(b'\0') if s]
   own=(len(args)>1 and args[1]==str(prep/'performance_v003_input_wrapper.py'))
   own=own or (len(args)>2 and args[1:3]==['-B','scripts/run_performance_r2_eoh_test_v06.py'] and (proc/'cwd').resolve()==prep)
   if own:
    pid=int(proc.name);assert os.getpgid(pid)==pid
    os.killpg(pid,signal.SIGSTOP);paused.append(pid)
  except (FileNotFoundError,ProcessLookupError,PermissionError):continue
 if paused:
  event={'transaction':name,'event':'pause','pids':paused,'unix':time.time(),'scope':'Input preparation only; no optimizer'}
  with (prep/'input_preparation_pause_events.jsonl').open('a') as f:f.write(json.dumps(event)+'\n')
  (ROOT/f'{name}.input_pause.json').write_text(json.dumps({'pids':paused,'input_root':str(prep)},indent=2)+'\n')
 with (ROOT/f'{name}.wrapper.log').open('xb') as log:
  child=subprocess.Popen([PYTHON,str(ROOT/'eoh_server_transaction_wrapper_v06.py'),name],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 print(json.dumps({'transaction':name,'pid':child.pid,'input_preparation_groups_paused':paused,'staging_receipt_sha256':sha256((ROOT/f'{name}.staging_receipt.json').read_bytes()).hexdigest()}))

if __name__=='__main__':main()
