"""Transport-only detached transaction wrapper; never reads candidate contents."""
from pathlib import Path
from hashlib import sha256
import argparse,json,os,platform,resource,signal,subprocess,tarfile,time

ROOT=Path(__file__).resolve().parent
PYTHON='/root/autodl-tmp/aamas2027_v03/py311/bin/python'
RELEASE='6f3a7059c92bebbf2905cdf51a9eda681a73d8990f3f254fc567c3b461ad9c35'
STUDY=Path('experiments/discovery/v06_published_eoh_001')

def digest(p):return sha256(Path(p).read_bytes()).hexdigest()

def main():
 p=argparse.ArgumentParser();p.add_argument('transaction');p.add_argument('--request-id');args=p.parse_args()
 name=args.transaction
 assert name.startswith('run_') and all(c.isalnum() or c=='_' for c in name)
 request_name=args.request_id or name
 assert request_name.startswith('run_') and all(c.isalnum() or c=='_' for c in request_name)
 request=STUDY/'requests'/f'{request_name}.json'
 out=STUDY/'server_results'/name
 log=ROOT/f'{name}.log';receipt=ROOT/f'{name}.transport_receipt.json'
 assert not (ROOT/out).exists() and not log.exists() and not receipt.exists()
 assert digest(ROOT/STUDY/'root_authoring_release.json')==RELEASE
 cmd=[PYTHON,'-B','-m','cipheur.published_eoh_v06','evaluate','--study',str(STUDY),
      '--request',str(request),'--out',str(out),'--root-release-sha256',RELEASE]
 start=time.monotonic();usage=resource.getrusage(resource.RUSAGE_CHILDREN)
 began=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime());timed=False
 with log.open('xb') as stream:
  process=subprocess.Popen(cmd,cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
  try:exitcode=process.wait(timeout=7200)
  except subprocess.TimeoutExpired:
   timed=True;os.killpg(process.pid,signal.SIGKILL);exitcode=process.wait()
 endusage=resource.getrusage(resource.RUSAGE_CHILDREN)
 files={f.name:digest(f) for f in (ROOT/out).glob('*') if f.is_file()} if (ROOT/out).exists() else {}
 value={'transaction':name,'command':cmd,'request_sha256':digest(ROOT/request),
        'root_release_sha256':RELEASE,'wrapper_sha256':digest(__file__),
        'started_utc':began,'finished_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),
        'wall_seconds':time.monotonic()-start,'child_user_cpu_seconds':endusage.ru_utime-usage.ru_utime,
        'child_system_cpu_seconds':endusage.ru_stime-usage.ru_stime,'exit_code':exitcode,
        'guard_seconds':7200,'guard_triggered':timed,'python':platform.python_version(),
        'TEST_accessed':False,'retry':False,'result_file_sha256':files,'log_sha256':digest(log)}
 receipt.write_text(json.dumps(value,indent=2)+'\n')
 archive=ROOT/f'{name}.tar.gz'
 with tarfile.open(archive,'x:gz') as tar:
  if (ROOT/out).exists():tar.add(ROOT/out,arcname=f'{name}/results')
  for path in [receipt,log,Path(__file__),ROOT/'host_staging_receipt.json',ROOT/'snapshot_path_compatibility_receipt.json']:
   tar.add(path,arcname=f'{name}/{path.name}')
 assert archive.stat().st_size<100_000_000
 (ROOT/f'{name}.archive_receipt.json').write_text(json.dumps({'sha256':digest(archive),'size':archive.stat().st_size,'transaction':name,'exit_code':exitcode,'guard_triggered':timed},indent=2)+'\n')

if __name__=='__main__':main()
